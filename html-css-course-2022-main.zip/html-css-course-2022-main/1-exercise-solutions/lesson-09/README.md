# Exercises
![exercises9-1](https://user-images.githubusercontent.com/70604577/160038997-ed03dd0e-fcd7-4896-abe7-223eba485b21.png)
![exercises9-2](https://user-images.githubusercontent.com/70604577/160039006-2b004fce-e1b2-4909-ab97-a374a9bd8598.png)
![exercises9-3](https://user-images.githubusercontent.com/70604577/160039012-668a59ca-901c-4fcd-ba7f-aaa299df817c.png)
