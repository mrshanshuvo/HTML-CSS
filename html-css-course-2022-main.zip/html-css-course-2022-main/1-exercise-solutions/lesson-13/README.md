# Exercises
![exercises13-1](https://user-images.githubusercontent.com/70604577/160039515-8d5c9d4b-b738-4642-af39-24e272d22240.png)
![exercises13-2](https://user-images.githubusercontent.com/70604577/160039523-bdf4b0fb-56a3-468e-a0d9-48e204ffcc89.png)
![exercises13-3](https://user-images.githubusercontent.com/70604577/160039532-00c02c22-3de4-4670-804c-acc651c1348d.png)
