# Exercises
![exercises1-1](https://user-images.githubusercontent.com/70604577/160036623-8bde6501-5ee6-4577-92a4-6ffbc02e858b.png)
![exercises1-2](https://user-images.githubusercontent.com/70604577/160036632-89153aef-a2ab-40a4-9fd8-7684513deedc.png)
