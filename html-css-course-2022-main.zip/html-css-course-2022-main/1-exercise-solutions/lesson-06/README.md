# Exercises
![Exercises 6](https://user-images.githubusercontent.com/70604577/160038643-817dc585-b7f9-4b93-b2f1-8a32f8ca5b69.png)
